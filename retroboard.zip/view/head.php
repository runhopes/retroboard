<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<title>İlan Tasarımı </title>

<script src="assets/js/loader.js"></script>

<link href="template/assets/img/favicon.ico" rel="icon" type="image/x-icon" />
<link href="template/assets/css/loader.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&display=swap" rel="stylesheet">
<link href="template/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="template/assets/css/plugins.css" rel="stylesheet" type="text/css" />

<link href="template/plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
<link href="template/assets/css/dashboard/dash_2.css" rel="stylesheet" type="text/css" />

<link href="template/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
<link href="template/assets/css/components/cards/card.css" rel="stylesheet" type="text/css" />


<link href="template/assets/css/elements/miscellaneous.css" rel="stylesheet" type="text/css" />
<link href="template/assets/css/elements/breadcrumb.css" rel="stylesheet" type="text/css" />

<link href="template/assets/css/forms/theme-checkbox-radio.css" rel="stylesheet" type="text/css" >
<link href="template/plugins/lightbox/photoswipe.css" rel="stylesheet" type="text/css" />
<link href="template/plugins/lightbox/default-skin/default-skin.css" rel="stylesheet" type="text/css" />
<link href="template/plugins/lightbox/custom-photswipe.css" rel="stylesheet" type="text/css" />

<link href="template/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
<link href="template/assets/css/components/custom-media_object.css" rel="stylesheet" type="text/css" />

<link href="template/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" type="text/css" >
<link href="template/plugins/file-upload/file-upload-with-preview.min.css" rel="stylesheet" type="text/css" />

<link href="template/assets/css/tables/table-basic.css" rel="stylesheet" type="text/css" />

<link href="template/assets/css/elements/alert.css" rel="stylesheet" type="text/css" >
<link href="template/plugins/loaders/custom-loader.css" rel="stylesheet" type="text/css" />


<link href="template/assets/css/apps/scrumboard.css" rel="stylesheet" type="text/css" />
<link href="template/assets/css/forms/theme-checkbox-radio.css" rel="stylesheet" type="text/css">

<link href="template/assets/css/elements/alert.css" rel="stylesheet" type="text/css" >
<style>
    .layout-px-spacing {
        min-height: calc(100vh - 170px)!important;
    }
</style>
