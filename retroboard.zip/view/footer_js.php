<script src="template/assets/js/libs/jquery-3.1.1.min.js"></script>
<script src="template/bootstrap/js/popper.min.js"></script>
<script src="template/bootstrap/js/bootstrap.min.js"></script>
<script src="template/assets/js/app.js"></script>
<script>
    $(document).ready(function() {
        App.init();
    });
</script>
<script src="template/assets/js/custom.js"></script>
<script src="template/assets/js/ie11fix/fn.fix-padStart.js"></script>
<script src="template/assets/js/apps/scrumboard.js"></script>
<script src="request/ajax/scrum.js?<?=rand()?>"></script>

